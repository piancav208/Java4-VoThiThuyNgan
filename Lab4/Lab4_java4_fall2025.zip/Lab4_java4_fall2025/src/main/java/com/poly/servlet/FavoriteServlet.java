package com.poly.servlet;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

import com.poly.dao.FavoritesDao;
import com.poly.entity.Favorite;
import com.poly.entity.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/id-search")
public class FavoriteServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setAttribute("favorite", Collections.emptyList()); // list trống khi load trang lần đầu
        req.getRequestDispatcher("/views/id-search.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String userId = req.getParameter("id");
        if (userId == null || userId.trim().isEmpty()) {
            req.setAttribute("error_id", "Vui lòng nhập ID người dùng.");
            req.setAttribute("favorite", Collections.emptyList());
            req.getRequestDispatcher("/views/id-search.jsp").forward(req, resp);
            return;
        }

        try {
            List<Favorite> favorites = FavoritesDao.findFavoritesByUserIdJPQL(userId);

            if (!favorites.isEmpty()) {
                User user = favorites.get(0).getUser();
                req.setAttribute("user", user);
                req.setAttribute("favorite", favorites);
            } else {
                req.setAttribute("error_id", "Không tìm thấy người dùng (ID: " + userId + ") hoặc người dùng chưa có video yêu thích.");
                req.setAttribute("favorite", Collections.emptyList());
            }

        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error_id", "Lỗi truy vấn dữ liệu: " + e.getMessage());
            req.setAttribute("favorite", Collections.emptyList());
        }

        req.getRequestDispatcher("/views/id-search.jsp").forward(req, resp);
    }
}
