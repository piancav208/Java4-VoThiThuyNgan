package com.poly.dao;

import java.util.List;

import com.poly.entity.User;
import com.poly.utils.JpaUtils;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

public class UserDao2 implements TongquatDao<User, String>{
	private EntityManager em = JpaUtils.getEntityManager();
	@Override
	public List<User> findAll() 
	{
		String jpql = "Select o from User o";
		TypedQuery<User> query = em.createQuery(jpql, User.class);
		return query.getResultList();
	}

	@Override
	public User findById(String id) {
		return em.find(User.class, id);
	}

	@Override
	public void create(User entity) {
		try {
			em.getTransaction().begin();
			
			em.merge(entity); // ham sua
			em.getTransaction().commit();
		} catch (Exception e) {
			em.getTransaction().rollback();
			throw new RuntimeException(e);
			// TODO: handle exception
		}
		
	}

	@Override
	public void update(User entity) {
		try {
			em.getTransaction().begin();
			
			em.merge(entity); // ham sua
			em.getTransaction().commit();
		
		} catch (Exception e) {
			em.getTransaction().rollback();
			throw new RuntimeException(e);
			// TODO: handle exception
		}
		
	}

	@Override
	public void deleteById(String id) 
	{
		try {
			em.getTransaction().begin();
			User entity = this.findById(id);
			
			em.remove(entity);
			em.getTransaction().commit();
				} catch (Exception e) {
			em.getTransaction().rollback();
			throw new RuntimeException(e);
			// TODO: handle exception
		}
		
	}

}
