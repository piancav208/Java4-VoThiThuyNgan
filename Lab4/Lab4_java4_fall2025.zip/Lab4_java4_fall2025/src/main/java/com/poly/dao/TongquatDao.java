package com.poly.dao;

import java.util.List;

import com.poly.entity.User;
 public interface TongquatDao<E,K> 
{
	List<User> findAll(); 
	 /**Truy vấn theo mã*/ 
	 User findById(String id); 
	 /**Thêm mới*/ 
	 void create(User item); 
	 /**Cập nhật*/ 
	 void update(User item); 
	 /**Xóa theo mã*/ 
	 void deleteById(String id);

}
