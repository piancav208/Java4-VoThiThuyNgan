package com.poly.dao;

import java.util.Collections;
import java.util.List;

import com.poly.entity.Favorite;
import com.poly.utils.JpaUtils;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

public class FavoritesDao {

    public static List<Favorite> findFavoritesByUserIdJPQL(String userId) {
        EntityManager em = JpaUtils.getEntityManager();
        try {
            // Join fetch luôn video để tránh LazyInitializationException
            String jpql = "SELECT f FROM Favorite f JOIN FETCH f.video WHERE f.user.id = :uid";
            TypedQuery<Favorite> query = em.createQuery(jpql, Favorite.class);
            query.setParameter("uid", userId);
            List<Favorite> result = query.getResultList();
            return result != null ? result : Collections.emptyList();
        } finally {
            em.close();
        }
    }
}
