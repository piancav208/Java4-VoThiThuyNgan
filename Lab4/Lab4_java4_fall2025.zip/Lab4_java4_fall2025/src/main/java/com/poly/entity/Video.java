package com.poly.entity;

import java.util.List;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import org.hibernate.annotations.*;

@NamedNativeQueries({
	@NamedNativeQuery(name = "Report.random10",
			query = "Select top 10 * from Video order by newid()", 
			resultClass = Video.class)
})

@Entity
@Table(name = "Video")
public class Video {
	@Id
	@Column(name = "Id")
	String id;
	
	@Column(name = "Title")
	String title;
	
	@Column(name = "Poster")
	String poster;
	
	@Column(name = "Description")
	String description;
	
	@Column(name = "Views")
	Integer views = 0;
	
	@Column(name = "Active")
	Boolean active;
	
	@Column(name = "Category")
	String category;
	
	@OneToMany(mappedBy = "video")
	List<Favorite> favorites;
	
	// Constructors
	public Video() {}
	
	public Video(String id, String title, String poster, String description, Integer views, Boolean active,
			String category, List<Favorite> favorites) { // Đã thêm Category
		super();
		this.id = id;
		this.title = title;
		this.poster = poster;
		this.description = description;
		this.views = views;
		this.active = active;
		this.category = category;
		this.favorites = favorites;
	}
	
	// Getters and Setters (Giữ nguyên)
	public String getCategory() { return category; }
	public void setCategory(String category) { this.category = category; }

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPoster() {
		return poster;
	}

	public void setPoster(String poster) {
		this.poster = poster;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getViews() {
		return views;
	}

	public void setViews(Integer views) {
		this.views = views;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public List<Favorite> getFavorites() {
		return favorites;
	}

	public void setFavorites(List<Favorite> favorites) {
		this.favorites = favorites;
	}

}