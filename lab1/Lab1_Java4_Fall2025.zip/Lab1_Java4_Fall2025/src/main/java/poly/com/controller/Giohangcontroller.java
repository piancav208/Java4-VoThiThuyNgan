package poly.com.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import poly.com.model.CartItem1;
import poly.com.model.Item;
@WebServlet("/giohang")
public class Giohangcontroller extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		 HttpSession session = req.getSession();
	        List<CartItem1> cartItems = (List<CartItem1>) session.getAttribute("cartItems"); 

	    
	        if (cartItems == null) {
	            cartItems = new ArrayList<>();
	        }

	        
	        List<Item> items = new ArrayList<>();
	        items.add(new Item("Reflex", "hatcat4.jpg", 500, 0.1));
	        items.add(new Item("Kit cat", "hatcat5.png", 700, 0.15));
	        items.add(new Item("Snappy Tom", "hatcat6.jpg", 900, 0.25));
	        items.add(new Item("Pedigree", "hatdog1.png", 55, 0.3));

	        req.setAttribute("items", items);
		req.getRequestDispatcher("cart.jsp").forward(req, resp);
	}

}
